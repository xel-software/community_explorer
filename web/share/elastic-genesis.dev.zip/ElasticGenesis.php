<?php

require_once('vendor/autoload.php');

use BitWasp\Bitcoin\Key\PublicKeyFactory;

class ElasticGenesis
{

    private $genesisDonations;
    private $readyListFilePath;
    private $apiUrl;
    private $apiFormat;

    public function __construct(string $genesisFilePath = '')
    {

        if(!file_exists($genesisFilePath)) {

            throw new \Exception("Couldn't find genesis file provided in param");

        }

        $genesisFileContent = file_get_contents($genesisFilePath);

        $this->genesisDonations = json_decode($genesisFileContent);

        $this->apiUrl = 'https://blockchain.info';
        $this->apiFormat = 'json';
        $this->readyListFilePath = 'readyList.txt';

    }

    private function getRefundedAddresses()
    {

        return [

            "1AKo8QK11FurGNvCnKuHvDFEFdavDRMZGo",
            "16MmuQWvJuNqJRLgoYfwvBeqVHr3BqmFwk",
            "13HfJkxPLJhTrCJEQSP3h6AZ23f63HpRGM"

        ];

    }

    public function generate()
    {

        $readyList = $this->parseGenesisJson();

        $sum = 0;

        foreach($readyList as $address => &$amount) {

            if(in_array($address, $this->getRefundedAddresses())) {

                unset($readyList[$address]);

            }

            $amount = round($amount, 4, PHP_ROUND_HALF_UP);

            $sum += $amount;

        }

        arsort($readyList);

        echo 'list generated successfully' . PHP_EOL;

        $this->writeAsPrintr($readyList);


    }

    private function parseGenesisJson()
    {

        $readyList = [];

        foreach($this->genesisDonations as $donation) {

            $pubKey = $donation->owner_pubkey;

            if(strpos($pubKey, '[ALL]') !== false) {

                $tx = $donation->btc_tx;

                $txInfo = $this->getTxInfoFromApi($tx);

                $address = $txInfo->inputs[0]->prev_out->addr;

            } else if(strlen($donation->owner_pubkey) === 34) {

                $address = $donation->owner_pubkey;

            } else {

                $publicKey = PublicKeyFactory::fromHex($pubKey);
                $address = $publicKey->getAddress()->getAddress();

            }

            if(!isset($readyList[$address])) {

                $readyList[$address] = 0;

            }

            $readyList[$address] += (max(min(-(5119.0609969033/25920.0)*((int)$donation->btc_block-400000)+10238.1219938066,10238.1219938066),0) * $donation->btc_amount) * 20;

        }

        return $readyList;

    }

    private function writeAsPrintr(array $readyList)
    {

        file_put_contents($this->readyListFilePath, print_r($readyList, true));

        echo 'list saved in ' . $this->readyListFilePath . PHP_EOL;

    }

    private function getTxInfoFromApi(string $tx)
    {

        $apiTxUrl = $this->apiUrl . '/tx-index/' . $tx .'?format=' . $this->apiFormat;
        return json_decode(file_get_contents($apiTxUrl));

    }

}