<?php

require_once ('ElasticGenesis.php');

$genesisParser = new ElasticGenesis('genesis-block.json');

$genesisParser->generate();
